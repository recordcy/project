

const form=document.getElementById('loginForm');
form.addEventListener('submit',e=>{e.preventDefault();const email=document.getElementById('email').value;const password=document.getElementById('password').value;if(!email||!password){alert('이메일과 비밀번호를 모두 입력해주세요.');return;}alert('로그인 시도 중...');/* 기존 로그인 기능 로직 유지 */});
