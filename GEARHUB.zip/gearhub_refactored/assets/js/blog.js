
/* ================== 백엔드 연동 – 블로그 API ==================
GET /api/blogs?query=&tag=&sort=latest|popular&page=1&pageSize=20
응답 예시:
{
  items:[{id,title,author,date,views,likes,tags:["텐트"],cover,text,links:[{label,href}]}],
  tags:["텐트","랜턴",...],
  trending:["텐트","리빙쉘",...],
  aiRecommendations:[{id,title}],
  total:128
}
============================================================== */

const state = { items:[], tags:[], trending:[], ai:[] };

async function fetchBlogs() {
  const params = new URLSearchParams({
    query: document.getElementById('q').value || '',
    tag: window.activeTag || '',
    sort: document.getElementById('sort').value || 'latest',
    page: 1, pageSize: 50
  });
  try{
    const r = await fetch('/api/blogs?'+params.toString(), {credentials:'include'});
    if(!r.ok) throw new Error('bad');
    const data = await r.json();
    state.items = data.items || [];
    state.tags  = data.tags  || [];
    state.trending = data.trending || state.tags.slice(0,8);
    state.ai = data.aiRecommendations || [];
  }catch(e){
    // —— 폴백 더미 데이터 —— //
    state.items = [
      {id:"p1",title:"겨울 백패킹: 자충매트 8cm 실사용 체감",author:"이캠린",date:"2025-10-22",views:2134,likes:312,tags:["백패킹","매트","동계"],cover:"images/blog_pad_8cm.jpg",text:"8cm와 5cm 비교, R-value 팁.",links:[{label:"자충매트 보기",href:"category.html?cat=매트&sub=자충매트"}]},
      {id:"p2",title:"리빙쉘 스트링 각도 & 페그",author:"트레일노트",date:"2025-10-18",views:1872,likes:201,tags:["텐트","리빙쉘","설치"],cover:"images/blog_livingshell_angle.jpg",text:"바람 많은 날 셋업 요령.",links:[{label:"리빙쉘 모아보기",href:"category.html?cat=텐트&sub=리빙쉘"}]},
      {id:"p3",title:"충전식 랜턴 3000K vs 5000K",author:"캠퍼로그",date:"2025-10-15",views:2541,likes:298,tags:["랜턴","전기","팁"],cover:"images/blog_warm_lantern.jpg",text:"벌레 유입·럭스 비교.",links:[{label:"랜턴 보기",href:"category.html?cat=랜턴&sub=충전식"}]},
      {id:"p4",title:"트윈버너 연료효율 실테스트",author:"아웃도어샷",date:"2025-10-10",views:3112,likes:420,tags:["버너","가스","테스트"],cover:"images/blog_twin_burner_test.jpg",text:"풍절음/화력 유지/호환성."}
    ];
    state.tags = Array.from(new Set(state.items.flatMap(x=>x.tags)));
    state.trending = state.tags.slice(0,8);
    state.ai = [
      {id:"r1", title:"동계 침낭 레이어링, 실제 체감 온도"},
      {id:"r2", title:"하드쿨러 24/48시간 잔빙률 비교"},
      {id:"r3", title:"사각 타프, 쉘터처럼 쓰는 법"},
      {id:"r4", title:"로체어 vs 릴렉스체어 선택 가이드"},
      {id:"r5", title:"가스버너 폭발 방지 체크리스트"}
    ];
  }
}

function drawChips(){
  const chipRow = document.getElementById('chipRow');
  chipRow.innerHTML = state.tags.map(t=>`<button class="chip" data-t="${t}">${t}</button>`).join('');
  chipRow.onclick = (e)=>{
    const el = e.target.closest('.chip'); if(!el) return;
    window.activeTag = (window.activeTag===el.dataset.t) ? '' : el.dataset.t;
    [...chipRow.children].forEach(c=>c.classList.toggle('active', c.dataset.t===window.activeTag));
    refresh();
  };
  const trend = document.getElementById('trend');
  trend.innerHTML = state.trending.map(t=>`<button class="chip" data-t="${t}">${t}</button>`).join('');
  trend.onclick = (e)=>{
    const el = e.target.closest('.chip'); if(!el) return;
    window.activeTag = el.dataset.t;
    [...chipRow.children].forEach(c=>c.classList.toggle('active', c.dataset.t===window.activeTag));
    refresh();
  };
}

function drawFeed(){
  const feed = document.getElementById('feed');
  const q = (document.getElementById('q').value||'').toLowerCase();
  const sort = document.getElementById('sort').value;
  let list = state.items.filter(x=>!window.activeTag || x.tags.includes(window.activeTag));
  if(q) list = list.filter(x => (x.title+x.text+x.author).toLowerCase().includes(q));
  if(sort==='popular') list.sort((a,b)=>b.views-a.views); else list.sort((a,b)=>a.date<b.date?1:-1);

  feed.innerHTML = list.map(p=>`
    <article class="card" data-id="${p.id}">
      <div class="thumb"><img src="${p.cover}" alt=""></div>
      <div class="meta"><b>${p.author}</b> · ${p.date} · 조회 ${p.views.toLocaleString()}</div>
      <div class="title">${p.title}</div>
      <div class="body">${p.text}</div>
      <div class="tags">${(p.tags||[]).map(t=>`<span class="tag">${t}</span>`).join('')}</div>
      <div class="actions">
        <button class="btn" data-open="${p.id}">자세히</button>
        <button class="btn" onclick="location.href='category.html'">관련상품</button>
      </div>
    </article>
  `).join('') || `<div class="small">결과가 없습니다.</div>`;
}

function drawTopReads(){
  const box = document.getElementById('topReads');
  const sorted = state.items.slice().sort((a,b)=>b.views-a.views).slice(0,5);
  box.innerHTML = sorted.map((p,i)=>`
    <div class="rank"><div class="rno">${i+1}</div>
      <div><div style="font-weight:900">${p.title}</div>
      <div class="small">${p.author} · 조회 ${p.views.toLocaleString()}</div></div>
    </div>`).join('');
}

function drawAI(){
  const list = document.getElementById('aiList');
  list.innerHTML = (state.ai||[]).slice(0,5).map(a=>`
    <div class="ai-item"><div class="ai-dot"></div>
      <a class="ai-title" href="blog.html#${a.id}">${a.title}</a>
    </div>`).join('') || `<div class="small">추천 준비 중</div>`;
}

async function refresh(){ await fetchBlogs(); drawChips(); drawFeed(); drawTopReads(); drawAI(); }
refresh();

document.getElementById('q').addEventListener('input', ()=>drawFeed());
document.getElementById('sort').addEventListener('change', ()=>refresh());
document.getElementById('aiRefresh').addEventListener('click', async ()=>{
  try{ const r=await fetch('/api/blogs/ai', {credentials:'include'}); if(r.ok){ const d=await r.json(); state.ai=d.items||state.ai; } }catch(e){}
  drawAI();
});

/* modal */
const modal=document.getElementById('modal');
document.getElementById('feed').addEventListener('click',e=>{
  const btn=e.target.closest('[data-open]'); if(!btn) return;
  const p=state.items.find(x=>x.id===btn.dataset.open); if(!p) return;
  mImg.src=p.cover; mTitle.textContent=p.title;
  mMeta.textContent=`${p.author} · ${p.date} · 조회 ${p.views.toLocaleString()}`;
  mText.textContent=p.text;
  mLinks.innerHTML=(p.links||[]).map(l=>`<a class="link" href="${l.href}">${l.label}</a>`).join('');
  modal.style.display='flex';
});
modal.addEventListener('click',e=>{ if(!e.target.closest('.sheet')) modal.style.display='none'; });
