
/* ===== 공통: 로그인 링크 토글 ===== */
(function(){
  const link=document.getElementById('authLink');
  function refresh(){
    const t=localStorage.getItem('accessToken');
    if(t){ link.textContent='마이페이지'; link.href='mypage.html'; }
    else{ link.textContent='로그인'; link.href='login.html'; }
  }
  refresh(); addEventListener('storage',e=>{ if(e.key==='accessToken') refresh(); });
})();

/* ===== 공통: 카테고리 메가메뉴 ===== */
const CATS={
  "텐트":["1~2인용","3~4인용","5인 이상","원터치","돔형","리빙쉘","백패킹"],
  "버너":["싱글버너","트윈버너","가스버너","화로대 겸용"],
  "랜턴":["충전식","건전지형","걸이형","감성랜턴"],
  "매트":["에어매트","폼매트","자충매트","전기매트"],
  "의자":["릴렉스체어","로체어","하이체어","벤치"],
  "타프":["사각타프","윙타프","쉘터"],
  "아이스박스":["하드형","소프트형","전동쿨러"]
};
const mega=document.getElementById('mega'), megaInner=document.getElementById('megaInner');
megaInner.innerHTML=Object.entries(CATS).map(([big,subs])=>`
  <div>
    <h3>${big}</h3>
    <ul>${subs.map(s=>`<li><a href="category.html?cat=${encodeURIComponent(big)}&sub=${encodeURIComponent(s)}">${s}</a></li>`).join('')}</ul>
  </div>`).join('');
const catBtn=document.getElementById('catBtn');
catBtn.addEventListener('mouseenter',()=>mega.classList.add('open'));
mega.addEventListener('mouseleave',()=>mega.classList.remove('open'));

/* ===== 페이지 상태  ===== */
const url=new URL(location.href);
let currentBig = url.searchParams.get('cat') || '텐트';
let currentSub = url.searchParams.get('sub') || '';
document.getElementById('title').textContent = currentSub? `${currentBig} · ${currentSub}` : currentBig;
document.getElementById('crumb').textContent = `홈 › 카테고리 › ${currentBig}${currentSub?' › '+currentSub:''}`;

/* ===== 큰 카테고리 행 + 하위 패널  ===== */
const bigCats=document.getElementById('bigCats');
bigCats.innerHTML=Object.keys(CATS).map(big=>{
  const subs=CATS[big];
  return `<div class="cat-chip ${big===currentBig?'active':''}" data-big="${big}">
    ${big}
    <div class="sub-panel">
      ${subs.map(s=>`<a href="#" data-sub="${s}" data-parent="${big}">${s}</a>`).join('')}
    </div>
  </div>`;
}).join('');
bigCats.addEventListener('click',e=>{
  const chip=e.target.closest('.cat-chip');
  if(!chip) return;
  currentBig=chip.dataset.big; currentSub=''; refreshAll();
});
bigCats.addEventListener('click',e=>{
  const a=e.target.closest('.sub-panel a');
  if(!a) return;
  e.preventDefault();
  currentBig=a.dataset.parent; currentSub=a.dataset.sub;
  refreshAll();
});

/* ===== Mock 데이터 (실서버 연결시 USE_MOCK=false 후 fetch 교체) ===== */
const USE_MOCK=true;

// 카테고리별 대표 이미지들
const BIG_IMAGE = {
  "텐트":      "images/pop_dome_tent.jpg",
  "버너":      "images/nl_burner.jpg",
  "랜턴":      "images/nl_lantern.jpg",
  "매트":      "images/reco_pad.jpg",
  "의자":      "images/pop_low_chair.jpg",
  "타프":      "images/reco_tarp.jpg",
  "아이스박스": "images/reco_cooler.jpg"
};

const IMG_MAP={
  "텐트":{
    "돔형":["1501785888041-af3ef285b470","1500534314209-a26db0f5a1c3","1500530855697-b586d89ba3ee"],
    "리빙쉘":["1500534314209-a26db0f5a1c3","1477414348463-c0eb7f1359b6"],
    "백패킹":["1501785888041-af3ef285b470","1523419409543-8f5fcf84c1d4"],
    "원터치":["1500534314209-a26db0f5a1c3"],
    "1~2인용":["1501785888041-af3ef285b470"],
    "3~4인용":["1500534314209-a26db0f5a1c3"],
    "5인 이상":["1477414348463-c0eb7f1359b6"]
  },
  "버너":{
    "싱글버너":["1543352634-8732c7732463","1514516870926-20598903f63c"],
    "트윈버너":["1543352634-8732c7732463"],
    "가스버너":["1514516870926-20598903f63c"],
    "화로대 겸용":["1502139214984-158f86c1dfb5"]
  },
  "랜턴":{
    "충전식":["1500043357865-c6b8827edf39","1447752875215-b2761acb3c5d"],
    "건전지형":["1447752875215-b2761acb3c5d"],
    "걸이형":["1500043357865-c6b8827edf39"],
    "감성랜턴":["1500043357865-c6b8827edf39"]
  },
  "매트":{
    "에어매트":["1601047130574-587e3999d1f6","1616628182504-0d1b0b5f4e6e"],
    "폼매트":["1616628182504-0d1b0b5f4e6e"],
    "자충매트":["1601047130574-587e3999d1f6"],
    "전기매트":["1616628182504-0d1b0b5f4e6e"]
  },
  "의자":{
    "릴렉스체어":["1607082349566-187342b8f00c","1607082349308-17e6b2b04c73"],
    "로체어":["1607082349308-17e6b2b04c73"],
    "하이체어":["1607082349566-187342b8f00c"],
    "벤치":["1607082349566-187342b8f00c"]
  },
  "타프":{
    "사각타프":["1500534314209-a26db0f5a1c3","1477414348463-c0eb7f1359b6"],
    "윙타프":["1477414348463-c0eb7f1359b6"],
    "쉘터":["1500534314209-a26db0f5a1c3"]
  },
  "아이스박스":{
    "하드형":["1598899134739-24c46f58b8e1"],
    "소프트형":["1598899134739-24c46f58b8e1"],
    "전동쿨러":["1598899134739-24c46f58b8e1"]
  }
};

// 더미 상품 생성기
function mockProducts(big, sub, count = 36){
  const list = [];
  for(let i=0; i<count; i++){
    const name  = `${sub || big} ${i+1}`;
    const base  = Math.floor((big.charCodeAt(0) + i*13) % 50) * 1000 + 19000;
    const price = Math.max(9000, base);
    const img   = getImageUrl(big, sub); 

    list.push({ big, sub: sub || "", name, price, img, popular: Math.random(), ts: Date.now() - i*3600*1000 });
  }
  return list;
}
function getImageUrl(big, sub){
  
  if (BIG_IMAGE[big]) return BIG_IMAGE[big];
  const pool = (IMG_MAP[big] && IMG_MAP[big][sub || Object.keys(IMG_MAP[big])[0]])
               || ["1500534314209-a26db0f5a1c3"];
  return `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=1400&q=80`;
}

function pickImage(big, sub){
  const pool = (IMG_MAP[big] && IMG_MAP[big][sub||Object.keys(IMG_MAP[big])[0]]) || ["1500534314209-a26db0f5a1c3"];
  return pool[Math.floor(Math.random()*pool.length)];
}

let ALL=[];  // 전체 상품 캐시
let PAGE=0, PAGE_SIZE=12;

/* ===== 데이터 로드 ===== */
async function loadData(){
  if(USE_MOCK){
    ALL = mockProducts(currentBig, currentSub, 48);
  }else{
    // 예시: 실제 연동
    // const url = `/api/products?cat=${encodeURIComponent(currentBig)}&sub=${encodeURIComponent(currentSub||"")}`;
    // ALL = await fetch(url).then(r=>r.json());
  }
  PAGE=0;
  renderPage(true);
  updateCount();
}

/* ===== 정렬 ===== */
const sortSel=document.getElementById('sortSel');
function applySort(){
  const v=sortSel.value;
  if(v==='popular') ALL.sort((a,b)=>b.popular-a.popular);
  if(v==='low') ALL.sort((a,b)=>a.price-b.price);
  if(v==='high') ALL.sort((a,b)=>b.price-a.price);
  if(v==='new') ALL.sort((a,b)=>b.ts-a.ts);
}
sortSel.addEventListener('change',()=>{ applySort(); renderPage(true); });

/* ===== 렌더링 ===== */
const grid=document.getElementById('grid');
function cardHTML(p){return `
  <article class="card">
    <div class="thumb"><img src="${p.img}" alt=""></div>
    <div class="meta">
      <span class="badge">${p.sub||p.big}</span>
      <div class="name">${p.name}</div>
      <div class="price">${p.price.toLocaleString()}원</div>
      <div class="actions">
        <button class="btn" data-like="${p.name}">♡ 찜</button>
        <button class="btn primary" data-compare="${p.name}">가격 비교</button>
      </div>
    </div>
  </article>`;}
function renderPage(reset=false){
  if(reset) grid.innerHTML='';
  applySort();
  const slice = ALL.slice(PAGE*PAGE_SIZE, (PAGE+1)*PAGE_SIZE);
  grid.insertAdjacentHTML('beforeend', slice.map(cardHTML).join(''));
  document.getElementById('moreBtn').style.display = (ALL.length > (PAGE+1)*PAGE_SIZE) ? 'inline-block' : 'none';
}
document.getElementById('moreBtn').addEventListener('click',()=>{ PAGE++; renderPage(false); });
function updateCount(){ document.getElementById('resultCount').textContent = `총 ${ALL.length.toLocaleString()}개`; }

/* ===== 검색 (카테고리 내) ===== */
document.getElementById('btnSearch').onclick=()=>{
  const q=document.getElementById('q').value.trim();
  if(!q){ loadData(); return; }
  const filtered = ALL.filter(x=> x.name.toLowerCase().includes(q.toLowerCase()) );
  PAGE=0; grid.innerHTML = filtered.slice(0,PAGE_SIZE).map(cardHTML).join('');
  document.getElementById('moreBtn').style.display = filtered.length>PAGE_SIZE ? 'inline-block':'none';
  document.getElementById('resultCount').textContent = `검색 결과 ${filtered.length.toLocaleString()}개`;
};

/* ===== 찜 (localStorage) ===== */
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-like]');
  if(!b) return;
  const key='wish';
  const name=b.getAttribute('data-like');
  const list=JSON.parse(localStorage.getItem(key)||'[]');
  if(!list.includes(name)) list.push(name);
  localStorage.setItem(key, JSON.stringify(list));
  b.textContent='💖';
});

/* ===== 가격 비교 모달 ===== */
const modal=document.getElementById('cmpModal');
const cmpName=document.getElementById('cmpName');
const cmpTable=document.getElementById('cmpTable');
let currentBestUrl="#";
async function comparePrices(name){
  // 실제 연동 예: return fetch(`/api/compare?name=${encodeURIComponent(name)}`).then(r=>r.json());
  const base = name.length%5;
  return [
    {site:"쿠팡", price:29000+base*1700, url:"https://www.coupang.com/"},
    {site:"네이버", price:27900+base*1800, url:"https://smartstore.naver.com/"},
    {site:"11번가", price:30500+base*1600, url:"https://www.11st.co.kr/"}
  ];
}
document.addEventListener('click',async e=>{
  const btn=e.target.closest('[data-compare]'); if(!btn) return;
  const name=btn.getAttribute('data-compare');
  const rows=await comparePrices(name);
  cmpName.textContent=`${name} 가격 비교`;
  cmpTable.innerHTML = rows.map(r=>`<div class="row"><span>${r.site}</span><span>${r.price.toLocaleString()}원</span></div>`).join('');
  currentBestUrl = rows.slice().sort((a,b)=>a.price-b.price)[0].url;
  modal.classList.add('open'); modal.setAttribute('aria-hidden','false');
});
document.getElementById('cmpClose').onclick=()=>{ modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); };
document.getElementById('cmpGo').onclick=()=>{ location.href=currentBestUrl; };
modal.addEventListener('click',e=>{ if(e.target===modal) document.getElementById('cmpClose').click(); });

/* ===== 초기 렌더 & 상태 동기화 ===== */
function refreshAll(){
  // big chip active 표시
  Array.from(bigCats.children).forEach(ch=>{
    ch.classList.toggle('active', ch.dataset.big===currentBig);
  });
  document.getElementById('title').textContent = currentSub? `${currentBig} · ${currentSub}` : currentBig;
  document.getElementById('crumb').textContent = `홈 › 카테고리 › ${currentBig}${currentSub?' › '+currentSub:''}`;
  // 데이터 로드
  loadData();
}

refreshAll();
