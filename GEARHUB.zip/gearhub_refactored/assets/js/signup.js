
  const $ = id => document.getElementById(id);
  $('signupForm').addEventListener('submit', async (e)=>{
    e.preventDefault();
    const name = $('name').value.trim();
    const email = $('email').value.trim();
    const password = $('password').value.trim();
    $('msg').textContent = '';
    if(!name || !email || !password){ $('msg').textContent = '모든 항목을 입력해 주세요.'; return; }
    try{
      const res = await apiPost('/auth/signup', { name, email, password });
      localStorage.setItem('accessToken', res.accessToken);
      location.href = '/mypage.html';
    }catch(err){
      $('msg').textContent = err?.message || '회원가입에 실패했습니다.';
    }
  });
