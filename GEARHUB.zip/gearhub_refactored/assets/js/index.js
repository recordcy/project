
/* 로그인 → 마이페이지 토글 */
(function(){
  const link=document.getElementById('authLink');
  function refresh(){ const t=localStorage.getItem('accessToken'); link.textContent=t?'마이페이지':'로그인'; link.href=t?'mypage.html':'login.html'; }
  refresh(); addEventListener('storage',e=>{ if(e.key==='accessToken') refresh(); });
})();

/* 카테고리 메가메뉴 */
const CATS={
  "텐트":["1~2인용","3~4인용","5인 이상","원터치","돔형","리빙쉘","백패킹"],
  "버너":["싱글버너","트윈버너","가스버너","화로대 겸용"],
  "랜턴":["충전식","건전지형","걸이형","감성랜턴"],
  "매트":["에어매트","폼매트","자충매트","전기매트"],
  "의자":["릴렉스체어","로체어","하이체어","벤치"],
  "타프":["사각타프","윙타프","쉘터"],
  "아이스박스":["하드형","소프트형","전동쿨러"]
};
const mega=document.getElementById('mega'), megaInner=document.getElementById('megaInner');
megaInner.innerHTML=Object.entries(CATS).map(([big,subs])=>`
  <div class="cat"><h3>${big}</h3>
    <ul>${subs.map(s=>`<li><a href="category.html?cat=${encodeURIComponent(big)}&sub=${encodeURIComponent(s)}">${s}</a></li>`).join('')}</ul>
  </div>`).join('');
document.getElementById('catBtn').addEventListener('mouseenter',()=>mega.classList.add('open'));
mega.addEventListener('mouseleave',()=>mega.classList.remove('open'));

/* 검색  */
document.getElementById('sList').addEventListener('click',e=>{
  const li=e.target.closest('.s-item'); if(!li) return;
  document.getElementById('q').value=li.dataset.k;
});
const suggest=document.getElementById('suggest'), q=document.getElementById('q');
q.addEventListener('focus',()=>suggest.classList.add('open'));
document.addEventListener('click',(e)=>{ if(!e.target.closest('.search')) suggest.classList.remove('open'); });
document.getElementById('btnSearch').onclick=()=>{ const v=q.value.trim(); if(v) location.href=`category.html?q=${encodeURIComponent(v)}`; };


/* 인기 아이템 캐러셀  */
const pTrack=document.getElementById('pTrack');
const popItems=[
  {name:"릴렉스체어",price:39000,img:"images/chair.jpg",badges:["오늘출발","무료반품"],sub:"4.8★(1.2천)"},  
  {name:"하드쿨러 30L",price:69000,img:"images/hardcooler.jpg",badges:["보냉테스트","쿠폰"],sub:"4.7★(842)"},   
  {name:"트윈버너",price:84000,img:"images/twinburner.jpg",badges:["MD추천"],sub:"4.9★(423)"},                 
  {name:"우드 롤테이블",price:59000,img:"images/woodroll.jpg",badges:["인기"],sub:"4.6★(1.1천)"},              
  {name:"충전식 랜턴",price:32000,img:"images/pop_lantern.jpg",badges:["감성"],sub:"4.8★(2.4천)"},                  
  {name:"돔형 텐트(2인)",price:129000,img:"images/pop_dome_tent.jpg",badges:["가성비"],sub:"4.7★(318)"},            
  {name:"로체어",price:29000,img:"images/pop_low_chair.jpg",badges:["HOT"],sub:"4.6★(679)"},                         
  {name:"사각 타프",price:74000,img:"images/pop_tarp_square.jpg",badges:["야외전시"],sub:"4.5★(211)"}              
];
pTrack.innerHTML=popItems.map(p=>`
  <div class="card-p">
    <div class="img"><img src="${p.img}" alt=""></div>
    <div class="txt">
      <div class="badges">${p.badges.map(b=>`<span class="badge">${b}</span>`).join('')}</div>
      <div class="pname">${p.name}</div>
      <div class="pprice">${p.price.toLocaleString()}원</div>
      <div class="psub">${p.sub}</div>
    </div>
  </div>`).join('');
function scrollByCards(dir=1){
  const card=pTrack.querySelector('.card-p'); if(!card) return;
  const gap=parseInt(getComputedStyle(pTrack).gap||'14',10);
  const step=(card.offsetWidth+gap)*4;
  pTrack.scrollBy({left:dir*step,behavior:'smooth'});
}
document.getElementById('pPrev').onclick=()=>scrollByCards(-1);
document.getElementById('pNext').onclick=()=>scrollByCards(1);

/* 블로그 페이지  */
const blogPages=[
  [ // Page 1
    {blog:"by. 이캠린", title:"겨울 백패킹 필수템 체크리스트", hero:"images/blog_winter_pack.jpg", 
     items:[
       {img:"images/blog_item_dome_tent.jpg", title:"2인용 돔형 텐트", price:129000, meta:"가성비 베스트"}, 
       {img:"images/blog_item_twin_burner.jpg", title:"트윈버너 세트", price:84000, meta:"불꽃 안정"},       
       {img:"images/blog_item_lantern.jpg", title:"충전식 랜턴 800lm", price:32000, meta:"따뜻한 3000K"}     
     ]},
    {blog:"by. 바라누스브", title:"감성 캠핑 테이블 세팅", hero:"images/blog_table_setup.jpg",            
     items:[
       {img:"images/blog_item_roll_table.jpg", title:"우드 롤테이블", price:59000, meta:"폴딩식"},          
       {img:"images/blog_item_relax_chair.jpg", title:"릴렉스체어", price:39000, meta:"거실감성"},          
       {img:"images/blog_item_cooler.jpg", title:"하드쿨러 35L", price:69000, meta:"보냉테스트"}           
     ]}
  ],
  [ // Page 2
    {blog:"by. 트레일노트", title:"비·바람 대비 리빙쉘 셋업", hero:"images/blog_livingshell.jpg",       
     items:[
       {img:"images/blog_item_livingshell.jpg", title:"리빙쉘 텐트", price:299000, meta:"스트링 각도 팁"}, 
       {img:"images/blog_item_tarp.jpg", title:"사각 타프", price:74000, meta:"쉘터 겸용"},                
       {img:"images/blog_item_pad.jpg", title:"자충매트 8cm", price:54000, meta:"동계용"}                
     ]},
    {blog:"by. 캠퍼로그", title:"로체어 vs 하이체어 체감 차이", hero:"images/blog_chair_compare.jpg",     
     items:[
       {img:"images/blog_item_lowchair.jpg", title:"로체어", price:29000, meta:"휴대성↑"},                  
       {img:"images/blog_item_relax_chair2.jpg", title:"릴렉스체어", price:39000, meta:"편안함↑"},         
       {img:"images/blog_item_side_table.jpg", title:"우드 사이드테이블", price:35000, meta:"보조용"}      
     ]}
  ]
];
let bIndex=0;
function renderBlogPage(){
  const g=document.getElementById('blogGrid');
  const page=blogPages[bIndex];
  g.innerHTML=page.map(b=>`
    <article class="bcard">
      <div class="bhead">
        <div>
          <div class="tag">blog <span>${b.blog}</span></div>
          <div class="btitle">${b.title}</div>
        </div>
        <div class="bthumb"><img src="${b.hero}" alt=""></div>
      </div>
      <div class="blist">
        ${b.items.map(it=>`
          <div class="bitem">
            <div class="bimg"><img src="${it.img}" alt=""></div>
            <div>
              <div class="bi-title">${it.title}</div>
              <div class="bi-meta">${it.meta}</div>
              <div class="bi-price">${it.price.toLocaleString()}원</div>
            </div>
          </div>`).join('')}
      </div>
    </article>`).join('');
  document.getElementById('bPage').textContent=(bIndex+1)+" / "+blogPages.length;
}
renderBlogPage();
document.getElementById('bPrev').onclick=()=>{ bIndex=(bIndex-1+blogPages.length)%blogPages.length; renderBlogPage(); };
document.getElementById('bNext').onclick=()=>{ bIndex=(bIndex+1)%blogPages.length; renderBlogPage(); };

/* 뉴스레터 페이지 */
const newsletterPages=[
  [ // Page 1
    {title:"동계 자충매트 선택법", img:"images/nl_pad.jpg", src:"Newsletter"},           
    {title:"하드쿨러 보냉 실험",   img:"images/nl_cooler.jpg", src:"Newsletter"},         
    {title:"랜턴 색온도와 벌레",   img:"images/nl_lantern.jpg", src:"Newsletter"},        
    {title:"리빙쉘 스트링 각도",   img:"images/nl_string.jpg", src:"Newsletter"}         
  ],
  [ // Page 2
    {title:"백패킹 가방 무게배분", img:"images/nl_pack.jpg", src:"Newsletter"},          
    {title:"겨울 침낭 레이어링",   img:"images/nl_sleepingbag.jpg", src:"Newsletter"},    
    {title:"버너 화구 관리",       img:"images/nl_burner.jpg", src:"Newsletter"},        
    {title:"타프 셋업 요령",       img:"images/nl_tarp.jpg", src:"Newsletter"}           
  ]
];
let nIndex=0;
function renderNewsletter(){
  const row=document.getElementById('nlGrid');
  row.innerHTML=newsletterPages[nIndex].map(n=>`
    <article class="nl">
      <div class="nimg"><img src="${n.img}" alt=""></div>
      <div class="ntxt"><div class="ntitle"><a href="#">${n.title}</a></div><div class="nmeta">${n.src}</div></div>
    </article>`).join('');
  document.getElementById('nPage').textContent=(nIndex+1)+" / "+newsletterPages.length;
}
renderNewsletter();
document.getElementById('nPrev').onclick=()=>{ nIndex=(nIndex-1+newsletterPages.length)%newsletterPages.length; renderNewsletter(); };
document.getElementById('nNext').onclick=()=>{ nIndex=(nIndex+1)%newsletterPages.length; renderNewsletter(); };

/* 추천 아이템 */
const recos=[
  {name:"원터치 텐트", img:"images/reco_onetouch.jpg"},      
  {name:"티타늄 컵셋", img:"images/reco_titanium_cup.jpg"},  
  {name:"자충매트 8cm", img:"images/reco_pad.jpg"},          
  {name:"우든 랜턴걸이", img:"images/reco_hanger.jpg"},      
  {name:"하드 쿨러 35L", img:"images/reco_cooler.jpg"},      
  {name:"롤테이블 S", img:"images/reco_roll_table.jpg"},     
  {name:"로체어", img:"images/reco_low_chair.jpg"},          
  {name:"사각 타프", img:"images/reco_tarp.jpg"},            
  {name:"충전식 랜턴 800lm", img:"images/reco_lantern.jpg"}, 
  {name:"릴렉스체어", img:"images/reco_relax_chair.jpg"}    
];
document.getElementById('recoGrid').innerHTML=recos.map(r=>`
  <article class="rcard">
    <div class="rimg"><img src="${r.img}" alt=""></div>
    <div class="rname">${r.name}</div>
  </article>`).join('');
