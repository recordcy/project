
/* ===== Helpers & State ===== */
const $ = sel => document.querySelector(sel);
const $$ = sel => document.querySelectorAll(sel);
const state = { me:null, cart:[], blogs:[], wishlist:[], posts:[] };
const USE_MOCK_ON_ERROR = true;

/* ===== Init ===== */
document.addEventListener('DOMContentLoaded', async () => {
  bindTabs();
  bindActions();
  await loadMe();
  await Promise.all([loadCart(), loadBlogs(), loadWishlist(), loadMyPosts()]);
});

/* ===== Tabs ===== */
function bindTabs(){
  $$('.tab').forEach(btn=>{
    btn.addEventListener('click',()=>{
      $$('.tab').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const name = btn.dataset.tab;
      $$('.panel').forEach(p=>p.classList.remove('active'));
      $('#panel-'+name).classList.add('active');
    });
  });
}

/* ===== Profile / Actions ===== */
function bindActions(){
  $('#btnLogout').addEventListener('click', async ()=>{
    try{ await apiPost('/auth/logout', {});}catch(e){}
    localStorage.removeItem('accessToken');
    location.href='login.html';
  });
  $('#btnRefresh').addEventListener('click', async ()=>{
    await Promise.all([loadCart(true), loadBlogs(true), loadWishlist(true), loadMyPosts(true)]);
  });
}

/* ===== Loaders ===== */
async function loadMe(){
  try{ state.me = await apiGet('/me'); }
  catch(e){ if(!USE_MOCK_ON_ERROR) throw e; state.me = {name:'게스트', email:'guest@example.com'}; }
  renderProfile();
}
async function loadCart(force){
  try{ state.cart = await apiGet('/cart'+(force?'?t='+Date.now():'')); }
  catch(e){ if(!USE_MOCK_ON_ERROR) throw e; state.cart = mockCart(); }
  renderCart();
}
async function loadBlogs(force){
  try{ state.blogs = await apiGet('/saved-blogs'+(force?'?t='+Date.now():'')); }
  catch(e){ if(!USE_MOCK_ON_ERROR) throw e; state.blogs = mockBlogs(); }
  renderBlogs();
}
async function loadWishlist(force){
  try{ state.wishlist = await apiGet('/wishlist'+(force?'?t='+Date.now():'')); }
  catch(e){ if(!USE_MOCK_ON_ERROR) throw e; state.wishlist = mockWishlist(); }
  renderWishlist();
}
async function loadMyPosts(force){
  try{ state.posts = await apiGet('/my-posts'+(force?'?t='+Date.now():'')); }
  catch(e){ if(!USE_MOCK_ON_ERROR) throw e; state.posts = mockMyPosts(); }
  renderMyPosts();
}

/* ===== Renderers ===== */
function renderProfile(){
  const name = state.me?.name || '사용자';
  const email = state.me?.email || 'user@example.com';
  $('#pName').textContent = name;
  $('#pEmail').textContent = email;
  $('#avatar').textContent = (name[0]||'G').toUpperCase() + (name[1]?name[1].toUpperCase():'H');
}

function renderCart(){
  const g = $('#cartGrid'); g.innerHTML = '';
  const arr = state.cart || [];
  $('#cartCount').textContent = `${arr.length}개 상품`;
  $('#cartEmpty').style.display = arr.length ? 'none' : 'block';
  arr.forEach(item=>{
    const el = document.createElement('article');
    el.className='card';
    el.innerHTML = `
      <img class="thumb" src="${item.img}" alt="">
      <div class="cbody">
        <div class="cname">${escapeHtml(item.name)}</div>
        <div class="cmeta">${escapeHtml(item.sub||item.brand||'')}</div>
        <div class="crow">
          <div class="cprice">${nf(item.price)}원</div>
          <div class="qty"><input type="number" min="1" value="${item.qty||1}" data-id="${item.id}"></div>
        </div>
        <div class="crow">
          <button class="btn btn-outline" data-act="remove" data-id="${item.id}">삭제</button>
          <button class="btn btn-primary" data-act="checkout" data-id="${item.id}">최저가 보기</button>
        </div>
      </div>`;
    g.appendChild(el);
  });
  g.onclick = async (e)=>{
    const act = e.target.getAttribute('data-act');
    const id  = e.target.getAttribute('data-id');
    if(!act||!id) return;
    if(act==='remove'){
      try{ await apiDelete('/cart/'+id);}catch(e){}
      state.cart = state.cart.filter(x=>String(x.id)!==String(id));
      renderCart();
    }else if(act==='checkout'){
      const name = state.cart.find(x=>String(x.id)===String(id))?.name||'';
      alert('백엔드 연동: /api/compare?name='+encodeURIComponent(name));
    }
  };
}

function renderBlogs(){
  const g = $('#blogList'); g.innerHTML = '';
  const arr = state.blogs || [];
  $('#blogEmpty').style.display = arr.length ? 'none' : 'block';
  arr.forEach(b=>{
    const el = document.createElement('article');
    el.className='bitem';
    el.innerHTML=`
      <div class="bthumb">${b.thumb?`<img src="${b.thumb}" alt="">`:''}</div>
      <div class="bmeta">
        <div class="btitle">${escapeHtml(b.title)}</div>
        <div class="bdesc">${escapeHtml(b.excerpt||'')}</div>
        <div class="bactions">
          <a class="btn btn-outline" href="${b.url||'#'}" target="_blank" rel="noopener">원문 보기</a>
          <button class="btn btn-primary" data-id="${b.id}" data-act="unsave">스크랩 해제</button>
        </div>
      </div>`;
    g.appendChild(el);
  });
  g.onclick = async (e)=>{
    const act = e.target.getAttribute('data-act');
    const id  = e.target.getAttribute('data-id');
    if(act==='unsave' && id){
      try{ await apiDelete('/saved-blogs/'+id);}catch(e){}
      state.blogs = state.blogs.filter(x=>String(x.id)!==String(id));
      renderBlogs();
    }
  };
}

function renderWishlist(){
  const g = $('#wishGrid'); g.innerHTML = '';
  const arr = state.wishlist || [];
  $('#wishCount').textContent = `${arr.length}개`;
  $('#wishEmpty').style.display = arr.length ? 'none' : 'block';
  arr.forEach(item=>{
    const el = document.createElement('article');
    el.className='card';
    el.innerHTML = `
      <img class="thumb" src="${item.img}" alt="">
      <div class="cbody">
        <div class="cname">${escapeHtml(item.name)}</div>
        <div class="cmeta">${escapeHtml(item.sub||item.brand||'')}</div>
        <div class="crow">
          <div class="cprice">${nf(item.price)}원</div>
          <button class="btn btn-outline" data-id="${item.id}" data-act="remove">삭제</button>
        </div>
      </div>`;
    g.appendChild(el);
  });
  g.onclick = async (e)=>{
    const act = e.target.getAttribute('data-act');
    const id  = e.target.getAttribute('data-id');
    if(act==='remove' && id){
      try{ await apiDelete('/wishlist/'+id);}catch(e){}
      state.wishlist = state.wishlist.filter(x=>String(x.id)!==String(id));
      renderWishlist();
    }
  };
}

function renderMyPosts(){
  const g = $('#postList'); g.innerHTML = '';
  const arr = state.posts || [];
  $('#postCount').textContent = `${arr.length}개`;
  $('#postEmpty').style.display = arr.length ? 'none' : 'block';
  arr.forEach(p=>{
    const el = document.createElement('article');
    el.className='post';
    el.innerHTML = `
      <div class="pinfo">
        <div class="ptitle">${escapeHtml(p.title)}</div>
        <div class="pmeta">${escapeHtml(p.category||'')}${p.updatedAt?' · '+new Date(p.updatedAt).toLocaleDateString() : ''}</div>
      </div>
      <div class="pmeta">${escapeHtml(p.excerpt||'')}</div>
      <div class="pactions">
        <a class="btn btn-outline" href="${p.publicUrl||'#'}" target="_blank" rel="noopener">공개보기</a>
        <a class="btn btn-outline" href="${p.editUrl||'#'}">수정</a>
        <button class="btn btn-primary" data-id="${p.id}" data-act="delete">삭제</button>
      </div>`;
    g.appendChild(el);
  });
  g.onclick = async (e)=>{
    const act = e.target.getAttribute('data-act');
    const id  = e.target.getAttribute('data-id');
    if(act==='delete' && id){
      if(!confirm('정말 삭제할까요?')) return;
      try{ await apiDelete('/my-posts/'+id);}catch(e){}
      state.posts = state.posts.filter(x=>String(x.id)!==String(id));
      renderMyPosts();
    }
  };
}

/* ===== Mocks ===== */
function mockCart(){ return [
  {id:1, name:'돔형 3-4인용 텐트', sub:'텐트', price:129000, qty:1, img:'images/cats/tent.jpg'},
  {id:2, name:'충전식 LED 랜턴', sub:'랜턴', price:39000, qty:2, img:'images/cats/lantern.jpg'},
  {id:3, name:'트윈버너 스토브', sub:'버너', price:89000, qty:1, img:'images/cats/burner.jpg'}
];}
function mockBlogs(){ return [
  {id:11, title:'겨울 백패킹 필수템 체크리스트', excerpt:'영하에서도 버티는 텐트/매트/랜턴 조합 정리', url:'#', thumb:'images/blog_winter.jpg'},
  {id:12, title:'감성랜턴 6종 비교', excerpt:'밝기/배터리/분위기 모두 잡은 제품은?', url:'#', thumb:'images/blog_lantern.jpg'}
];}
function mockWishlist(){ return [
  {id:101, name:'구스다운 침낭 -10℃', sub:'침낭', price:159000, img:'images/cats/mat.jpg'},
  {id:102, name:'초경량 롤테이블', sub:'테이블', price:59000, img:'images/cats/chair.jpg'}
];}
function mockMyPosts(){ return [
  {id:201, title:'가을 감성 캠핑 세팅 가이드', category:'블로그', excerpt:'랜턴 톤·우드 테이블·체어 조합으로 무드 완성', updatedAt: Date.now()-86400000, publicUrl:'#', editUrl:'#'},
  {id:202, title:'백패킹 입문 장비 리스트', category:'리뷰', excerpt:'무게/예산/안전 기준으로 장비 구성하는 법', updatedAt: Date.now()-172800000, publicUrl:'#', editUrl:'#'}
];}

/* ===== Utils ===== */
function nf(n){return (n||0).toString().replace(/\B(?=(\d{3})+(?!\d))/g,',');}
function escapeHtml(s){return (s??'').replace(/[&<>"']/g,m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));}
