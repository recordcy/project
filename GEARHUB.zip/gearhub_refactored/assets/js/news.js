
/* ============ 백엔드 연동 – 뉴스레터 API =============
GET /api/newsletters?query=&topic=&sort=latest|popular&page=1&pageSize=12
응답:
{ items:[{id,topic,title,img,text,date,views,link}], total:42 }
====================================================== */

const st = { items:[], total:0, page:0, pageSize:12 };

async function fetchNews() {
  const params = new URLSearchParams({
    query: document.getElementById('q').value || '',
    topic: document.getElementById('topic').value || '',
    sort:  document.getElementById('sort').value || 'latest',
    page:  st.page+1, pageSize: st.pageSize
  });
  try{
    const r = await fetch('/api/newsletters?'+params.toString(), {credentials:'include'});
    if(!r.ok) throw new Error('bad');
    const data = await r.json();
    st.items = data.items || [];
    st.total = data.total || st.items.length;
  }catch(e){
    // —— 더미 폴백 —— //
    const ALL = [
      {id:"n1",topic:"가이드",title:"동계 캠핑 침낭 레이어링 완전정복",img:"images/nl_sleeping_layer.jpg",text:"-10℃ 대응 현실 팁",date:"2025-10-25",views:1800,link:"#sleep"},
      {id:"n2",topic:"추천템",title:"하드쿨러 35L 보냉 테스트",img:"images/nl_cooler_test.jpg",text:"24·36·48h 잔빙률",date:"2025-10-24",views:2300,link:"#cooler"},
      {id:"n3",topic:"안전",title:"가스버너 폭발 방지 체크리스트",img:"images/nl_gas_safety.jpg",text:"복합사용 금지·환기",date:"2025-10-22",views:3200,link:"#gas"},
      {id:"n4",topic:"캠핑장",title:"가을 성수기 인기 캠핑장 8선",img:"images/nl_campsites.jpg",text:"전기·반려·물놀이",date:"2025-10-20",views:1500,link:"#sites"},
      {id:"n5",topic:"추천템",title:"충전식 랜턴 3000K가 좋은 이유",img:"images/nl_lantern_cct.jpg",text:"벌레·눈 피로",date:"2025-10-19",views:2700,link:"#lantern"},
      {id:"n6",topic:"가이드",title:"리빙쉘 스트링 각도와 페깅",img:"images/nl_strings.jpg",text:"V자/크로스 비교",date:"2025-10-18",views:2100,link:"#string"},
      {id:"n7",topic:"캠핑장",title:"노키즈존 캠핑장 에티켓",img:"images/nl_etiquette.jpg",text:"소음·조명·반려",date:"2025-10-17",views:1100,link:"#etq"},
      {id:"n8",topic:"추천템",title:"우드 롤테이블 유지관리",img:"images/nl_rolltable.jpg",text:"오일링·유격",date:"2025-10-15",views:980,link:"#table"},
      {id:"n9",topic:"안전",title:"화로대 재처리 & 숯 폐기",img:"images/nl_firepit.jpg",text:"매몰·재가열 위험",date:"2025-10-14",views:1660,link:"#firepit"}
    ];
    // 간단 필터/정렬 폴백
    const q = (document.getElementById('q').value||'').toLowerCase();
    const topic = document.getElementById('topic').value;
    const sort  = document.getElementById('sort').value;
    let list = ALL.slice();
    if(topic) list = list.filter(x=>x.topic===topic);
    if(q) list = list.filter(x=>(x.title+x.text).toLowerCase().includes(q));
    if(sort==='popular') list.sort((a,b)=>b.views-a.views); else list.sort((a,b)=>a.date<b.date?1:-1);
    st.total = list.length;
    const start = st.page*st.pageSize;
    st.items = list.slice(start, start+st.pageSize);
  }
}

function drawNews(){
  const grid = document.getElementById('grid');
  grid.innerHTML = st.items.map(n=>`
    <article class="card">
      <div class="thumb"><img src="${n.img}" alt=""></div>
      <div class="text">
        <div class="kicker">${n.topic}</div>
        <div class="title">${n.title}</div>
        <div class="meta">${n.date} · 조회 ${n.views.toLocaleString()}</div>
        <div>${n.text}</div>
        <div class="actions">
          <button class="btn" onclick="location.href='${n.link}'">읽기</button>
          <button class="btn" onclick="location.href='category.html'">관련상품</button>
        </div>
      </div>
    </article>
  `).join('') || `<div class="meta">내용이 없습니다.</div>`;

  const totalPages = Math.max(1, Math.ceil(st.total/st.pageSize));
  document.getElementById('pageInfo').textContent = (st.page+1)+' / '+totalPages;
  document.getElementById('prev').disabled = st.page<=0;
  document.getElementById('next').disabled = st.page>=totalPages-1;
}

async function refresh(){ await fetchNews(); drawNews(); }
refresh();

document.getElementById('prev').onclick=()=>{ if(st.page>0){ st.page--; refresh(); } };
document.getElementById('next').onclick=()=>{ st.page++; refresh(); };
['q','topic','sort'].forEach(id=>document.getElementById(id).addEventListener('input',()=>{ st.page=0; refresh(); }));
